settings = {
    "display_mode": 0,
    "resolution": 0,
    "aspect_ratio": 1,
    "fps": 1,
    "vsync": False,
    "screen_shake": False,
    "motion_blur": False,
    "bloom": False,
    "pixel_filter": 0
}

display_modes = [
    "Windowed",
    "Borderless",
    "Fullscreen"
]

resolutions = [
    (800, 600),
    (1024, 768),
    (1280, 720),
    (1280, 960),
    (1600, 900),
    (1680, 720),
    (1920, 1080),
    (2560, 1080),
    (3440, 1440)
]

aspect_ratios = [
    "16:9",
    "4:3",
    "21:9"
]

fps_options = [30, 60, 120, 0]