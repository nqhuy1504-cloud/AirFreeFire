
import pygame


class Player:
    def __init__(self, x, y, speed=200):
        self.rect = pygame.Rect(x, y, 40, 40)
        self.speed = speed
        self.direction = "down"
        self.moving = False
        self.color = (0, 200, 255)

    def update(self, keys, bounds, dt):
        dx = 0
        dy = 0

        if keys[pygame.K_w] or keys[pygame.K_UP]:
            dy -= 1
            self.direction = "up"

        if keys[pygame.K_s] or keys[pygame.K_DOWN]:
            dy += 1
            self.direction = "down"

        if keys[pygame.K_a] or keys[pygame.K_LEFT]:
            dx -= 1
            self.direction = "left"

        if keys[pygame.K_d] or keys[pygame.K_RIGHT]:
            dx += 1
            self.direction = "right"

        self.moving = dx != 0 or dy != 0

        if self.moving:
            movement = pygame.Vector2(dx, dy).normalize() * self.speed * dt
            self.rect.x += round(movement.x)
            self.rect.y += round(movement.y)

        self.rect.clamp_ip(bounds)

    def draw(self, screen):
        pygame.draw.rect(screen, self.color, self.rect)
