@echo off
title Treasure Hunter

cd /d "%~dp0"

py main.py

pause