import pygame
import json
import math
import os
import random
import asyncio
from modules.settings import settings, display_modes, resolutions, aspect_ratios, fps_options

pygame.init()

WIDTH = 800
HEIGHT = 600

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Pháo binh đêm")

clock = pygame.time.Clock()
SQUAD_SCALE = 0.6
font_title = pygame.font.Font("assets/fonts/NotoSans-Bold.ttf", 42)
font_subtitle = pygame.font.Font("assets/fonts/NotoSans-Bold.ttf", 27)
font_button = pygame.font.Font("assets/fonts/NotoSans-Bold.ttf", 22)
font_small = pygame.font.Font("assets/fonts/NotoSans-Regular.ttf", 16)

WHITE = (255, 255, 255)
BLUE = (30, 100, 170)
DARK = (15, 25, 40)
GRAY = (55, 70, 90)
RED = (220, 60, 60)
GREEN = (90, 255, 140)

save_file = "data/save.json"

qualities = ["Thấp", "Trung bình", "Cao"]
quality_index = 1

state = "menu"
running = True

settings_tab = 0

settings_tabs = [
    "HIỂN THỊ",
    "HIỆU NĂNG",
    "ĐỒ HỌA"
]

# ====================== PIXEL ART ======================
P = 4  # kích thước 1 "pixel" trên màn hình

PALETTE = {
    "K": (20, 20, 28),
    "H": (75, 95, 60),
    "S": (230, 180, 140),
    "G": (60, 85, 55),
    "B": (110, 80, 50),
    "A": (175, 180, 192),
    "a": (105, 110, 128),
    "R": (210, 55, 55),
}

SOLDIER = [
    ".HHH.",
    "HHHHH",
    ".SSS.",
    "GGGGG",
    "GGGGG",
    ".G.G.",
    ".B.B.",
]

PLANE_LEFT = [  # mũi máy bay hướng sang trái
    ".....a......",
    ".....aa.....",
    "....aAa.....",
    "RaaAAAAAAAa.",
    "aAAAAAAAAAAa",
    "RaaAAAAAAAa.",
    "....aAa.....",
    ".....aa.....",
    ".....a......",
]

def make_sprite(rows, scale=P):
    h = len(rows)
    w = len(rows[0])
    surf = pygame.Surface((w * scale, h * scale), pygame.SRCALPHA)
    for gy, row in enumerate(rows):
        for gx, ch in enumerate(row):
            if ch in PALETTE:
                pygame.draw.rect(surf, PALETTE[ch], (gx * scale, gy * scale, scale, scale))
    return surf


soldier_img = make_sprite(SOLDIER,3)
plane_left_img = make_sprite(PLANE_LEFT)
plane_right_img = pygame.transform.flip(plane_left_img, True, False)


def make_glow():
    n = 28
    surf = pygame.Surface((n * 2 * P, n * 2 * P), pygame.SRCALPHA)
    for gx in range(-n, n):
        for gy in range(-n, n):
            d = math.hypot(gx, gy)
            if d <= 26:
                alpha = int(70 * (1 - d / 26))
                if d < 18 or (gx + gy) % 2 == 0:
                    pygame.draw.rect(
                        surf, (50, 75, 110, alpha),
                        ((gx + n) * P, (gy + n) * P, P, P)
                    )
    return surf

glow_img = make_glow()
glow_img = pygame.transform.scale(
    glow_img, (int(glow_img.get_width() * SQUAD_SCALE), int(glow_img.get_height() * SQUAD_SCALE)))

def snap(v):
    return int(round(v / P)) * P


def draw_box(rect, color):
    """Nút bấm kiểu pixel: không bo góc, có viền sáng/tối."""
    rect = pygame.Rect(rect)
    light = tuple(min(255, c + 45) for c in color)
    dark = tuple(max(0, c - 35) for c in color)

    pygame.draw.rect(screen, color, rect)
    pygame.draw.rect(screen, light, (rect.x, rect.y, rect.w, P))
    pygame.draw.rect(screen, light, (rect.x, rect.y, P, rect.h))
    pygame.draw.rect(screen, dark, (rect.x, rect.bottom - P, rect.w, P))
    pygame.draw.rect(screen, dark, (rect.right - P, rect.y, P, rect.h))
    pygame.draw.rect(screen, PALETTE["K"], rect, 2)


# ====================== GAMEPLAY ======================
MAX_HP = 5
FIRE_COOLDOWN = 0.9
SHELL_SPEED = 520        # px/giây (nhân theo kích thước màn hình)
BURST_RADIUS = 36
BURST_LIFE = 0.35
SWEEP_SPEED = math.tau / 2.2   # radar quét 1 vòng mỗi 2 giây
BLIP_LIFE = 2.1                # chấm radar mờ dần sau từng ấy giây
SHOW_RING = True               # hiện vòng tròn phòng thủ mờ trên màn hình

RADAR_R = 24       # bán kính radar (đơn vị pixel logic)
RADAR_SCALE = 3    # phóng to radar
RADAR_POS = (16, 16)

CANNON_OFFSETS = [(-34, -18), (34, -18), (0, 30)]
SOLDIER_OFFSETS = [(-16, 22), (18, 20), (0, -34)]

planes = []
shells = []
bursts = []
score = 0
hp = MAX_HP
game_time = 0.0
spawn_timer = 0.0
fire_timer = 0.0
flash_timer = 0.0
sweep_angle = 0.0
game_over = False
def center():
    return WIDTH // 2, HEIGHT // 2


def defense_radius():
    return int(min(WIDTH, HEIGHT) * 0.1)


def size_factor():
    return WIDTH / 800


def radar_range():
    return math.hypot(WIDTH / 2, HEIGHT / 2) + 40


def reset_game(keep_score=0, keep_time=0.0, keep_hp=MAX_HP):
    global planes, shells, bursts, score, hp, game_time
    global spawn_timer, fire_timer, flash_timer, sweep_angle, game_over
    planes = []
    shells = []
    bursts = []
    score = keep_score
    hp = keep_hp
    game_time = keep_time
    spawn_timer = 1.5
    fire_timer = 0.5
    flash_timer = 0.0
    sweep_angle = 0.0
    game_over = False


def current_plane_speed():
    return min(20 + game_time * 1.2, 90) * size_factor()


def current_spawn_interval():
    return max(0.9, 2.8 - game_time * 0.02)


def spawn_plane():
    side = random.choice([-1, 1])
    x = -30 if side < 0 else WIDTH + 30
    y = random.randint(int(HEIGHT * 0.08), int(HEIGHT * 0.92))
    planes.append({
        "x": float(x),
        "y": float(y),
        "speed": current_plane_speed() * random.uniform(0.85, 1.15),
        "phase": random.uniform(0, math.tau),
        "face_left": side > 0,
        "seen": None,
        "age": 0.0,
    })


def cannon_positions():
    cx, cy = center()
    return [(cx + ox*SQUAD_SCALE, cy + oy*SQUAD_SCALE) for ox, oy in CANNON_OFFSETS]


def aim_dir(px, py, target):
    dx = target[0] - px
    dy = target[1] - py
    length = math.hypot(dx, dy)
    if length < 1:
        return 1.0, 0.0
    return dx / length, dy / length


def fire(target):
    global fire_timer, flash_timer
    if fire_timer > 0 or game_over:
        return

    for px, py in cannon_positions():
        dx, dy = aim_dir(px, py, target)
        mx = px + dx * 34
        my = py + dy * 34

        tx = target[0] + random.randint(-12, 12)
        ty = target[1] + random.randint(-12, 12)

        vx = tx - mx
        vy = ty - my
        length = max(1, math.hypot(vx, vy))
        speed = SHELL_SPEED * size_factor()

        shells.append({
            "x": mx, "y": my,
            "tx": tx, "ty": ty,
            "vx": vx / length * speed,
            "vy": vy / length * speed,
        })

    fire_timer = FIRE_COOLDOWN
    flash_timer = 0.1


def add_burst(x, y, kind):
    if kind == "flak":
        bursts.append({"x": x, "y": y, "age": 0.0, "life": BURST_LIFE,
                       "r": BURST_RADIUS, "dmg": True, "light": 130, "kind": kind})
    elif kind == "kill":
        bursts.append({"x": x, "y": y, "age": 0.0, "life": 0.5,
                       "r": 30, "dmg": False, "light": 90, "kind": kind})
    else:  # hit: máy bay đánh trúng căn cứ
        bursts.append({"x": x, "y": y, "age": 0.0, "life": 0.6,
                       "r": 36, "dmg": False, "light": 110, "kind": kind})


def burst_radius(b):
    return b["r"] * min(1.0, 0.35 + b["age"] * 8)


def update_game(dt):
    global score, hp, game_time, spawn_timer, fire_timer, flash_timer
    global sweep_angle, game_over, planes, shells, bursts

    # hiệu ứng nổ vẫn chạy cả khi đã thua
    for b in bursts:
        b["age"] += dt
    bursts = [b for b in bursts if b["age"] < b["life"]]

    if game_over:
        return

    game_time += dt
    fire_timer = max(0, fire_timer - dt)
    flash_timer = max(0, flash_timer - dt)

    keys = pygame.key.get_pressed()
    if keys[pygame.K_SPACE] or pygame.mouse.get_pressed()[0]:
        fire(pygame.mouse.get_pos())

    # spawn máy bay từ hai bên trái / phải
    spawn_timer -= dt
    if spawn_timer <= 0:
        spawn_plane()
        spawn_timer = current_spawn_interval() * random.uniform(0.7, 1.3)

    cx, cy = center()

    # radar quét
    prev = sweep_angle
    delta = SWEEP_SPEED * dt
    sweep_angle = (sweep_angle + delta) % math.tau

    for p in planes:
        p["age"] += dt
        bearing = math.atan2(p["y"] - cy, p["x"] - cx) % math.tau
        if (bearing - prev) % math.tau <= delta:
            p["seen"] = (p["x"], p["y"])
            p["age"] = 0.0
        if p["seen"] is not None and p["age"] > BLIP_LIFE:
            p["seen"] = None

    # đạn pháo bay đến điểm ngắm rồi nổ
    kept = []
    for s in shells:
        dist = math.hypot(s["tx"] - s["x"], s["ty"] - s["y"])
        step = math.hypot(s["vx"], s["vy"]) * dt
        if dist <= step:
            add_burst(s["tx"], s["ty"], "flak")
        else:
            s["x"] += s["vx"] * dt
            s["y"] += s["vy"] * dt
            kept.append(s)
    shells = kept

    # máy bay bay thẳng về tâm (hơi lắc ngang)
    radius = defense_radius()
    alive = []
    for p in planes:
        dx = cx - p["x"]
        dy = cy - p["y"]
        dist = math.hypot(dx, dy)

        if dist <= radius:
            hp -= 1
            add_burst(p["x"], p["y"], "hit")
            continue

        ux, uy = dx / dist, dy / dist
        p["phase"] += dt * 2.2
        lateral = math.sin(p["phase"]) * 0.35

        vx = (ux - uy * lateral) * p["speed"]
        vy = (uy + ux * lateral) * p["speed"]

        p["x"] += vx * dt
        p["y"] += vy * dt
        p["face_left"] = vx < 0
        alive.append(p)
    planes = alive

    # nổ phòng không tiêu diệt máy bay
    survivors = []
    for p in planes:
        killed = False
        for b in bursts:
            if b["dmg"] and math.hypot(p["x"] - b["x"], p["y"] - b["y"]) < burst_radius(b) + 16:
                killed = True
                break
        if killed:
            score += 1
            add_burst(p["x"], p["y"], "kill")
        else:
            survivors.append(p)
    planes = survivors

    if hp <= 0:
        hp = 0
        game_over = True
        if os.path.exists(save_file):
            os.remove(save_file)


def is_lit(x, y):
    for b in bursts:
        fade = 1 - 0.5 * b["age"] / b["life"]
        if math.hypot(x - b["x"], y - b["y"]) < b["light"] * fade:
            return True
    return False


def draw_text(text, font, color, x, y):
    image = font.render(text, True, color)
    rect = image.get_rect(center=(x, y))
    screen.blit(image, rect)


# ---------- vẽ cảnh đêm ----------
def draw_defense_ring():
    cx, cy = center()
    r = defense_radius()
    count = max(24, int(math.tau * r / 18))
    for i in range(count):
        ang = i * math.tau / count
        x = snap(cx + math.cos(ang) * r)
        y = snap(cy + math.sin(ang) * r)
        pygame.draw.rect(screen, (45, 65, 90), (x, y, P, P))


def draw_squad():
    cx, cy = center()
    screen.blit(glow_img, (cx - glow_img.get_width() // 2, cy - glow_img.get_height() // 2))

    # bao cát quanh trận địa
    for i in range(20):
        ang = i * math.tau / 20
        bx = snap(cx + math.cos(ang) * 60 * SQUAD_SCALE) - 4
        by = snap(cy + math.sin(ang) * 60 * SQUAD_SCALE) - 3
        color = (110, 85, 55) if i % 2 == 0 else (90, 68, 45)
        pygame.draw.rect(screen, color, (bx, by, 8, 6))       
        pygame.draw.rect(screen, (140, 110, 75), (bx, by, 12, 2))

    # lính
    for ox, oy in SOLDIER_OFFSETS:
        screen.blit(soldier_img, (snap(cx + ox) - soldier_img.get_width() // 2,
                                  snap(cy + oy) - soldier_img.get_height() // 2))

    # 3 khẩu pháo xoay theo chuột
    mouse = pygame.mouse.get_pos()
    BARREL = int(34 * SQUAD_SCALE)

    for px, py in cannon_positions():
        dx, dy = aim_dir(px, py, mouse)

        pygame.draw.rect(screen, (70, 80, 92), (px - 7, py - 5, 14, 10))
        pygame.draw.rect(screen, (120, 130, 145), (px - 7, py - 5, 14, 3))

        for step in range(4, BARREL, P):
            bx = snap(px + dx * step) - P
            by = snap(py + dy * step) - P
            pygame.draw.rect(screen, (95, 105, 120), (bx, by, P * 2, P * 2))
            pygame.draw.rect(screen, (165, 175, 190), (bx, by, P * 2, P))

        ex = snap(px + dx * BARREL) - P
        ey = snap(py + dy * BARREL) - P
        pygame.draw.rect(screen, PALETTE["K"], (ex, ey, P * 2, P * 2))

        if flash_timer > 0:
            fx = snap(px + dx * (BARREL + 8)) - P
            fy = snap(py + dy * (BARREL + 8)) - P
            pygame.draw.rect(screen, (255, 230, 120), (fx - P, fy - P, P * 4, P * 4))
            pygame.draw.rect(screen, WHITE, (fx, fy, P * 2, P * 2))


def draw_burst(b):
    r = burst_radius(b) * (1 - 0.35 * b["age"] / b["life"])
    n = int(r / P)
    if n < 1:
        return

    if b["kind"] == "hit":
        palette = [(255, 220, 160), (255, 90, 50), (120, 25, 25)]
    elif b["kind"] == "kill":
        palette = [(255, 245, 190), (255, 170, 50), (150, 50, 20)]
    else:
        palette = [(255, 250, 210), (255, 200, 80), (190, 90, 30)]

    for gx in range(-n, n + 1):
        for gy in range(-n, n + 1):
            d = math.hypot(gx, gy) / n
            if d > 1:
                continue
            if d > 0.75 and (gx + gy) % 2:
                continue
            color = palette[0] if d < 0.35 else palette[1] if d < 0.7 else palette[2]
            pygame.draw.rect(screen, color,
                             (snap(b["x"]) + gx * P, snap(b["y"]) + gy * P, P, P))


def draw_shells():
    for s in shells:
        length = max(1, math.hypot(s["vx"], s["vy"]))
        ux, uy = s["vx"] / length, s["vy"] / length

        for i, color in ((2, (120, 90, 50)), (1, (200, 150, 70))):
            tx = snap(s["x"] - ux * i * P * 1.5)
            ty = snap(s["y"] - uy * i * P * 1.5)
            pygame.draw.rect(screen, color, (tx, ty, P, P))

        pygame.draw.rect(screen, (255, 235, 130), (snap(s["x"]), snap(s["y"]), P, P))


def draw_planes():
    for p in planes:
        if is_lit(p["x"], p["y"]):
            img = plane_left_img if p["face_left"] else plane_right_img
            screen.blit(img, (snap(p["x"] - img.get_width() / 2),
                              snap(p["y"] - img.get_height() / 2)))


def draw_crosshair():
    mx, my = pygame.mouse.get_pos()
    mx, my = snap(mx), snap(my)
    color = (130, 255, 170)

    for i in range(2, 6):
        pygame.draw.rect(screen, color, (mx + i * P, my, P, P))
        pygame.draw.rect(screen, color, (mx - i * P, my, P, P))
        pygame.draw.rect(screen, color, (mx, my + i * P, P, P))
        pygame.draw.rect(screen, color, (mx, my - i * P, P, P))
    pygame.draw.rect(screen, WHITE, (mx, my, P, P))


# ---------- radar ----------
def draw_radar():
    cx, cy = center()
    size = RADAR_R * 2 + 6
    mid = size // 2
    rs = pygame.Surface((size, size), pygame.SRCALPHA)

    pygame.draw.circle(rs, (5, 25, 14), (mid, mid), RADAR_R)
    pygame.draw.circle(rs, (18, 70, 40), (mid, mid), RADAR_R * 2 // 3, 1)
    pygame.draw.circle(rs, (18, 70, 40), (mid, mid), RADAR_R // 3, 1)
    pygame.draw.line(rs, (18, 70, 40), (mid - RADAR_R, mid), (mid + RADAR_R, mid))
    pygame.draw.line(rs, (18, 70, 40), (mid, mid - RADAR_R), (mid, mid + RADAR_R))

    scale = RADAR_R / radar_range()

    # vòng phòng thủ trên radar
    pygame.draw.circle(rs, (190, 70, 70), (mid, mid), max(2, int(defense_radius() * scale)), 1)

    # vệt quét
    for i, color in enumerate([(110, 255, 160), (60, 170, 100), (35, 110, 65), (20, 70, 40)]):
        ang = sweep_angle - i * 0.08
        pygame.draw.line(rs, color, (mid, mid),
                         (mid + math.cos(ang) * RADAR_R, mid + math.sin(ang) * RADAR_R))

    # chấm máy bay (vị trí lần quét gần nhất)
    for p in planes:
        if p["seen"] is None:
            continue
        bx = mid + (p["seen"][0] - cx) * scale
        by = mid + (p["seen"][1] - cy) * scale
        if math.hypot(bx - mid, by - mid) > RADAR_R - 1:
            continue
        f = max(0.25, 1 - p["age"] / BLIP_LIFE)
        color = (int(80 * f), int(255 * f), int(120 * f))
        pygame.draw.rect(rs, color, (int(bx) - 1, int(by) - 1, 3, 3))

    # đánh dấu điểm đang ngắm của chuột
    mx, my = pygame.mouse.get_pos()
    tx = mid + (mx - cx) * scale
    ty = mid + (my - cy) * scale
    if math.hypot(tx - mid, ty - mid) < RADAR_R - 2:
        t = (int(tx), int(ty))
        for ox, oy in ((-2, 0), (2, 0), (0, -2), (0, 2)):
            rs.set_at((t[0] + ox, t[1] + oy), (255, 255, 255))

    # tiểu đội ở tâm
    pygame.draw.rect(rs, (255, 255, 255), (mid - 1, mid - 1, 3, 3))

    big = pygame.transform.scale(rs, (size * RADAR_SCALE, size * RADAR_SCALE))
    rx, ry = RADAR_POS
    panel = pygame.Rect(rx - 8, ry - 8, big.get_width() + 16, big.get_height() + 16)

    pygame.draw.rect(screen, (10, 14, 22), panel)
    pygame.draw.rect(screen, (70, 90, 110), panel, P)
    screen.blit(big, (rx, ry))
    draw_text("RADAR", font_small, GREEN, panel.centerx, panel.bottom + 14)


def draw_hud():
    draw_text(f"ĐIỂM: {score}", font_button, WHITE, WIDTH - 110, 30)

    for i in range(MAX_HP):
        color = (220, 60, 60) if i < hp else (60, 35, 40)
        x = WIDTH - 30 - (MAX_HP - i) * (P * 5 + 6) + 6
        pygame.draw.rect(screen, color, (x, 55, P * 5, P * 4))
        pygame.draw.rect(screen, PALETTE["K"], (x, 55, P * 5, P * 4), 2)

    draw_text("CHUỘT / SPACE: BẮN PHÁO   ESC: MENU", font_small, (140, 160, 180),
              WIDTH // 2, HEIGHT - 20)


def draw_game():
    if background_img is not None:
        screen.blit(background_img, (0, 0))
        screen.blit(night_overlay, (0, 0))
    else:
        screen.fill((4, 6, 12))

    if SHOW_RING:
        draw_defense_ring()

    draw_squad()

    for b in bursts:
        draw_burst(b)

    draw_shells()
    draw_planes()

    draw_radar()
    draw_hud()
    draw_crosshair()

    if game_over:
        overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 160))
        screen.blit(overlay, (0, 0))

        draw_text("TRẬN ĐỊA THẤT THỦ!", font_title, RED, WIDTH // 2, HEIGHT // 2 - 50)
        draw_text(f"Máy bay bị hạ: {score}", font_subtitle, WHITE, WIDTH // 2, HEIGHT // 2 + 10)
        draw_text("ENTER: CHƠI LẠI   ESC: MENU", font_small, WHITE, WIDTH // 2, HEIGHT // 2 + 60)


# ====================== MENU / CÀI ĐẶT ======================
def make_button(y, width=300, height=55):
    return pygame.Rect(WIDTH // 2 - width // 2, y, width, height)


def make_tab_button(i):
    tab_width = 190
    tab_height = 55
    gap = 10

    total_width = tab_width * 3 + gap * 2
    start_x = WIDTH // 2 - total_width // 2

    return pygame.Rect(
        start_x + i * (tab_width + gap),
        165,
        tab_width,
        tab_height
    )


def make_arrow_buttons(y):
    x = WIDTH // 2 - 300

    left = pygame.Rect(x + 465, y - 22, 45, 44)
    right = pygame.Rect(x + 520, y - 22, 45, 44)

    return left, right


def draw_setting_row(label, value, y):
    x = WIDTH // 2 - 300

    row = pygame.Rect(x, y - 27, 600, 54)
    draw_box(row, GRAY)

    draw_text(label, font_button, WHITE, x + 155, y)
    draw_text(value, font_button, WHITE, x + 405, y)

    left, right = make_arrow_buttons(y)
    mouse = pygame.mouse.get_pos()

    left_color = BLUE if left.collidepoint(mouse) else DARK
    right_color = BLUE if right.collidepoint(mouse) else DARK

    draw_box(left, left_color)
    draw_box(right, right_color)

    draw_text("<", font_button, WHITE, left.centerx, left.centery)
    draw_text(">", font_button, WHITE, right.centerx, right.centery)


def draw_background():
    # bầu trời chia dải màu kiểu pixel
    bands = 8
    band_h = HEIGHT // bands + 1
    for i in range(bands):
        t = i / (bands - 1)
        color = (int(15 + 25 * t), int(25 + 30 * t), int(40 + 55 * t))
        pygame.draw.rect(screen, color, (0, i * band_h, WIDTH, band_h))

    counts = [15, 45, 90]
    count = counts[quality_index]
    ticks = pygame.time.get_ticks() // 600

    for i in range(count):
        x = snap((i * 137 + 43) % WIDTH)
        y = snap((i * 79 + 31) % HEIGHT)
        bright = (i + ticks) % 5 == 0
        color = (200, 220, 255) if bright else (90, 120, 160)
        pygame.draw.rect(screen, color, (x, y, P, P))

background_raw = None
background_img = None
night_overlay = None
def load_background(path="assets/background/jungle.jpg"):
    global background_raw
    if os.path.exists(path):
        background_raw=pygame.image.load(path).convert()
    else:
        background_raw=None
    scale_background()
def scale_background():
    global background_img, night_overlay

    if background_raw is None:
        background_img = None
        night_overlay = None
        return

    # transform.scale (không phải smoothscale) để giữ nét pixel
    background_img = pygame.transform.scale(background_raw, (WIDTH, HEIGHT))

    # lớp phủ tối để giữ cảm giác ban đêm (alpha 0-255, càng cao càng tối)
    night_overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
    night_overlay.fill((0, 0, 10, 170))
def save_game():
    os.makedirs("data", exist_ok=True)

    data = {
        "score": score,
        "time": game_time,
        "hp": hp
    }

    with open(save_file, "w", encoding="utf-8") as f:
        json.dump(data, f)


def load_game():
    if os.path.exists(save_file):
        with open(save_file, "r", encoding="utf-8") as f:
            data = json.load(f)

        reset_game(data.get("score", 0), data.get("time", 0.0), data.get("hp", MAX_HP))


def draw_menu():
    draw_background()

    draw_text("DỰ ÁN 18", font_title, WHITE, WIDTH // 2, 100)
    draw_text("GAME PYTHON SÁNG TẠO", font_subtitle, WHITE, WIDTH // 2, 160)
    draw_text("PHÁO BINH ĐÊM", font_subtitle, (100, 200, 255), WIDTH // 2, 220)

    names = ["CHƠI MỚI", "CHƠI TIẾP", "CÀI ĐẶT", "THOÁT"]

    for i, name in enumerate(names):
        button = make_button(285 + i * 70)
        color = BLUE if button.collidepoint(pygame.mouse.get_pos()) else GRAY

        if i == 1 and not os.path.exists(save_file):
            color = (40, 45, 55)

        draw_box(button, color)
        draw_text(name, font_button, WHITE, button.centerx, button.centery)


def draw_settings():
    draw_background()

    draw_text("CÀI ĐẶT", font_title, WHITE, WIDTH // 2, 85)

    for i, name in enumerate(settings_tabs):
        button = make_tab_button(i)

        color = BLUE if i == settings_tab else GRAY

        draw_box(button, color)
        draw_text(name, font_button, WHITE, button.centerx, button.centery)

    if settings_tab == 0:
        w, h = resolutions[settings["resolution"]]

        options = [
            ("CHẾ ĐỘ MÀN HÌNH", display_modes[settings["display_mode"]]),
            ("ĐỘ PHÂN GIẢI", f"{w} x {h}"),
            ("TỶ LỆ MÀN HÌNH", aspect_ratios[settings["aspect_ratio"]])
        ]

    elif settings_tab == 1:
        fps_text = str(fps_options[settings["fps"]]) + " FPS"

        options = [
            ("GIỚI HẠN FPS", fps_text)
        ]

    else:
        options = []
        draw_text(
            "CÁC TÙY CHỌN ĐANG ĐƯỢC PHÁT TRIỂN",
            font_small,
            WHITE,
            WIDTH // 2,
            300
        )

    for i, (label, value) in enumerate(options):
        draw_setting_row(label, value, 260 + i * 70)

    back_button = make_button(HEIGHT - 85, 250, 55)

    draw_box(back_button, GRAY)
    draw_text("QUAY LẠI", font_button, WHITE, back_button.centerx, back_button.centery)


def apply_display_settings():
    global WIDTH, HEIGHT, screen

    mode = settings["display_mode"]
    w, h = resolutions[settings["resolution"]]

    if mode == 0:
        WIDTH, HEIGHT = w, h
        flags = 0

    elif mode == 1:
        info = pygame.display.Info()
        WIDTH, HEIGHT = info.current_w, info.current_h
        flags = pygame.NOFRAME

    else:
        WIDTH, HEIGHT = w, h
        flags = pygame.FULLSCREEN

    screen = pygame.display.set_mode((WIDTH, HEIGHT), flags)
    scale_background()

def change_setting(row, direction):
    if settings_tab == 0:

        if row == 0:
            settings["display_mode"] = (settings["display_mode"] + direction) % len(display_modes)

        elif row == 1:
            settings["resolution"] = (settings["resolution"] + direction) % len(resolutions)

            w, h = resolutions[settings["resolution"]]

            if w * 9 == h * 16:
                settings["aspect_ratio"] = 0

            elif w * 3 == h * 4:
                settings["aspect_ratio"] = 1

            elif w * 9 == h * 21:
                settings["aspect_ratio"] = 2

        elif row == 2:
            settings["aspect_ratio"] = (settings["aspect_ratio"] + direction) % len(aspect_ratios)

            ratio = settings["aspect_ratio"]

            for i, (w, h) in enumerate(resolutions):
                if ratio == 0 and w * 9 == h * 16:
                    settings["resolution"] = i
                    break

                elif ratio == 1 and w * 3 == h * 4:
                    settings["resolution"] = i
                    break

                elif ratio == 2 and w * 9 == h * 21:
                    settings["resolution"] = i
                    break

        apply_display_settings()
    elif settings_tab == 1:
        settings["fps"] = (settings["fps"] + direction) % len(fps_options)


# ====================== VÒNG LẶP CHÍNH ======================
async def main():
    global state, running, settings_tab

    load_background()
    while running:
        fps = fps_options[settings["fps"]]
        dt = clock.tick(fps) / 1000
        dt = min(dt, 0.05)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                if state == "game" and not game_over:
                    save_game()
                running = False

            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:

                if state == "menu":
                    for i in range(4):
                        button = make_button(285 + i * 70)

                        if button.collidepoint(event.pos):
                            if i == 0:
                                reset_game()
                                state = "game"

                            elif i == 1:
                                if os.path.exists(save_file):
                                    load_game()
                                    state = "game"

                            elif i == 2:
                                state = "settings"

                            elif i == 3:
                                running = False

                elif state == "settings":
                    back_button = make_button(HEIGHT - 85, 250, 55)

                    if back_button.collidepoint(event.pos):
                        state = "menu"

                    else:
                        tab_clicked = False

                        for i in range(3):
                            button = make_tab_button(i)

                            if button.collidepoint(event.pos):
                                settings_tab = i
                                tab_clicked = True
                                break

                        if not tab_clicked:
                            row_count = [3, 1, 0][settings_tab]

                            for i in range(row_count):
                                y = 260 + i * 70
                                left, right = make_arrow_buttons(y)

                                if left.collidepoint(event.pos):
                                    change_setting(i, -1)
                                    break

                                elif right.collidepoint(event.pos):
                                    change_setting(i, 1)
                                    break

            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    if state == "game":
                        if not game_over:
                            save_game()
                        state = "menu"

                    elif state == "settings":
                        state = "menu"

                elif event.key == pygame.K_RETURN and state == "game" and game_over:
                    reset_game()

        pygame.mouse.set_visible(state != "game")

        if state == "game":
            update_game(dt)
            draw_game()

        elif state == "menu":
            draw_menu()

        elif state == "settings":
            draw_settings()

        pygame.display.update()
        await asyncio.sleep(0)

    pygame.quit()
asyncio.run(main())
